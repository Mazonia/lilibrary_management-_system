<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Library System</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Library System - Admin</h1>
        <nav>
            <ul>
                <li><a href="manage_books.php">Manage Books</a></li>
                <li><a href="manage_members.php">Manage Members</a></li>
                <li><a href="manage_borrowings.php">Manage Borrowings</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Admin Dashboard</h2>
    </main>
</body>
</html>
