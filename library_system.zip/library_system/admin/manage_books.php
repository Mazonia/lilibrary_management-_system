<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Manage Books</h1>
        <nav>
            <ul>
                <li><a href="index.php">Admin Dashboard</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form method="POST" action="">
            <h2>Add New Book</h2>
            <input type="text" name="title" placeholder="Title" required>
            <input type="text" name="author" placeholder="Author" required>
            <input type="number" name="publication_year" placeholder="Publication Year" required>
            <input type="text" name="genre" placeholder="Genre">
            <input type="text" name="isbn" placeholder="ISBN" required>
            <input type="number" name="available_copies" placeholder="Available Copies" required>
            <button type="submit" name="add_book">Add Book</button>
        </form>

        <?php
        include '../db.php';

        if (isset($_POST['add_book'])) {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $publication_year = $_POST['publication_year'];
            $genre = $_POST['genre'];
            $isbn = $_POST['isbn'];
            $available_copies = $_POST['available_copies'];

            $sql = "INSERT INTO Books (Title, Author, PublicationYear, Genre, ISBN, AvailableCopies) VALUES ('$title', '$author', $publication_year, '$genre', '$isbn', $available_copies)";
            if ($conn->query($sql) === TRUE) {
                echo "New book added successfully.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        if (isset($_GET['delete'])) {
            $bookID = $_GET['delete'];
            $sql = "DELETE FROM Books WHERE BookID = $bookID";
            if ($conn->query($sql) === TRUE) {
                echo "Book deleted successfully.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        if (isset($_POST['edit_book'])) {
            $bookID = $_POST['book_id'];
            $title = $_POST['title'];
            $author = $_POST['author'];
            $publication_year = $_POST['publication_year'];
            $genre = $_POST['genre'];
            $isbn = $_POST['isbn'];
            $available_copies = $_POST['available_copies'];

            $sql = "UPDATE Books SET Title='$title', Author='$author', PublicationYear=$publication_year, Genre='$genre', ISBN='$isbn', AvailableCopies=$available_copies WHERE BookID=$bookID";
            if ($conn->query($sql) === TRUE) {
                echo "Book updated successfully.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        $sql = "SELECT * FROM Books";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table><tr><th>ID</th><th>Title</th><th>Author</th><th>Publication Year</th><th>Genre</th><th>ISBN</th><th>Available Copies</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row['BookID'] . "</td><td>" . $row['Title'] . "</td><td>" . $row['Author'] . "</td><td>" . $row['PublicationYear'] . "</td><td>" . $row['Genre'] . "</td><td>" . $row['ISBN'] . "</td><td>" . $row['AvailableCopies'] . "</td>
                <td>
                <a href='edit_book.php?id=" . $row['BookID'] . "'>Edit</a> |
                <a href='manage_books.php?delete=" . $row['BookID'] . "' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                </td></tr>";
            }
            echo "</table>";
        } else {
            echo "No books found.";
        }
        $conn->close();
        ?>
    </main>
</body>
</html>
